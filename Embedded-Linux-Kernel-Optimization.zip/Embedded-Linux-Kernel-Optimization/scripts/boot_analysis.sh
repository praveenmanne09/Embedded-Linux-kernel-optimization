#!/bin/bash
echo "Embedded Linux Boot Analysis"
echo "----------------------------"
echo "1. Total Boot Time:"
systemd-analyze
echo ""
echo "2. Slowest Services:"
systemd-analyze blame | head -10
echo ""
echo "3. Critical Boot Chain:"
systemd-analyze critical-chain
echo ""
echo "4. Memory Usage:"
free -h
echo ""
echo "5. Recent Kernel Messages:"
dmesg | tail -20
