#!/bin/bash
echo "Starting service optimization..."

services=("bluetooth" "cups" "avahi-daemon")

for service in "${services[@]}"; do
    echo "Disabling $service ..."
    sudo systemctl disable "$service"
done

echo "Optimization complete."
echo "Please reboot and check boot time using:"
echo "systemd-analyze"
