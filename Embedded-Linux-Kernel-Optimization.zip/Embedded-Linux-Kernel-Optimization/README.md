# Embedded Linux Kernel Optimization - Boot Time Reduction and Performance Tuning

Analysis and optimization of Linux boot time using `systemd-analyze` and a
service-tuning shell script.

**Result:** userspace startup reduced from **22.287 s to 7.527 s (about 66 % faster)**.

## Contents
| File | Description |
|------|-------------|
| `README.pdf` | Project overview (PDF) |
| `docs/Project_Report.pdf` | Full report with screenshots and results |
| `docs/Scripts_and_Commands.pdf` | All commands and scripts, explained line by line |
| `scripts/optimize_services.sh` | Disables Bluetooth, CUPS and Avahi services |
| `scripts/boot_analysis.sh` | Boot analysis helper script |
| `screenshots/` | Terminal screenshots (before / after) |

## Quick start
```bash
chmod +x scripts/*.sh
./scripts/boot_analysis.sh        # baseline
./scripts/optimize_services.sh    # disable unneeded services
sudo reboot
systemd-analyze                   # compare
```
